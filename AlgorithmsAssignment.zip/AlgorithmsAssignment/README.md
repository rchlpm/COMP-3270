
# Algorithms Assigment

names:
Rachel Meredith
Kaitlyn Smith

All files included in zip file:
Algorithms Programming Assigment (doc file)
Main(1) (java file)
matrix first half (excel file)
phw_input (txt file)

IDE Used- Intellij
Language - java

Compile instructions:
add a main configuration and run the program. 

"I certify that I wrote the code I am submitting. I did not copy whole or parts of it from another student or 
have another person write the code for me. Any code I am reusing in my program is clearly marked as such 
with its source clearly identified in comments.” 
